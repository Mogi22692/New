
document.getElementById('generateBtn').addEventListener('click', function() {
    let randomEmail = generateRandomEmail();
    document.getElementById('fakeEmail').value = randomEmail;
    addEmailToInbox(randomEmail);
});

document.getElementById('clearInboxBtn').addEventListener('click', function() {
    clearInbox();
});

function generateRandomEmail() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let email = '';
    for (let i = 0; i < 10; i++) {
        email += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return email + '@tempemail.com';
}

function addEmailToInbox(email) {
    const emailList = document.getElementById('emailList');
    const li = document.createElement('li');
    li.textContent = email;
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.classList.add('deleteBtn');
    deleteBtn.onclick = function() {
        deleteEmail(li);
    };
    li.appendChild(deleteBtn);
    emailList.appendChild(li);
    saveEmails();
}

function deleteEmail(emailElement) {
    const emailList = document.getElementById('emailList');
    emailList.removeChild(emailElement);
    saveEmails();
}

function clearInbox() {
    const emailList = document.getElementById('emailList');
    emailList.innerHTML = '';
    localStorage.removeItem('emails');
}

function saveEmails() {
    const emailList = document.getElementById('emailList');
    const emails = [];
    emailList.querySelectorAll('li').forEach(li => {
        emails.push(li.textContent.replace('Delete', '').trim());
    });
    localStorage.setItem('emails', JSON.stringify(emails));
}

function loadEmails() {
    const emails = JSON.parse(localStorage.getItem('emails'));
    if (emails) {
        emails.forEach(email => {
            addEmailToInbox(email);
        });
    }
}

window.onload = loadEmails;
